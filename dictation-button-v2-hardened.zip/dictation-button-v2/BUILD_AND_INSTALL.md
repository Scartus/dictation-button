# Build and install v2

## Easiest build

1. Create a private GitHub repository.
2. Upload the contents of this folder.
3. Open **Actions → Build Android APK → Run workflow**.
4. Download the generated APK artifact.
5. Open the APK on the Android phone and allow installation from that source when Android asks.

## First-run setup

The app guides each state rather than assuming setup succeeded:

1. **Continue with ChatGPT** and approve eligible ChatGPT-plan usage.
2. **Allow microphone**.
3. **Enable Dictation Button keyboard** in Android settings.
4. **Choose Dictation Button** as the current keyboard.
5. Tap the in-app test field and run a short dictation.

The app shows **Using ChatGPT plan** when connected. **Manage ChatGPT usage** opens ChatGPT Settings → Usage.

## Daily use

Open any editable text field, switch to Dictation Button, tap **Dictate**, speak, then tap **Stop recording**. Switch back to Samsung Keyboard for normal typing.

## Recovery

- Network/service failure: the newest failed recording is encrypted locally and can be retried.
- Focus changed: completed transcript remains encrypted as recovered text instead of being inserted into the wrong field.
- Neither recovered text nor failed audio is kept indefinitely; v2 expires recovery after 24 hours.
- You can explicitly discard recovered text or delete the saved recording.

## Not yet claimed

The source has been statically audited here, but the APK has not been physically tested on the target Samsung device in this environment. Bluetooth routing, calls, browser OAuth callback behavior, OEM battery management and TalkBack should be exercised using `docs/TEST_MATRIX_V2.md`.
