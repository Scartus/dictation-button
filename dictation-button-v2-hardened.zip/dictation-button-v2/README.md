# Dictation Button v2 prototype

A hardened Android voice-only IME for accurate system-wide dictation using eligible ChatGPT plan usage through Sign in with ChatGPT.

## Intended daily flow

1. Tap a text field.
2. Switch to **Dictation Button** if it is not already selected.
3. Tap **Dictate**.
4. Speak.
5. Tap **Stop recording**.
6. Text is inserted only after a fully completed response and only if the same editor is still active.

If focus changed, insertion failed, the network failed, or the plan hit a usage limit, v2 fails closed and keeps recoverable material locally instead of guessing.

## v2 hardening highlights

- OAuth registration separated from renewable token session.
- Wrong-client/wrong-account OAuth returns rejected.
- Refresh tokens and recovered text protected by Android Keystore AES-GCM.
- Failed recordings encrypted at rest; only the newest is kept and recovery expires after 24 hours.
- Sign-out attempts remote refresh-token revocation.
- No API key and no backend server.
- Responses requests require `store:false`, `stream:true`, and `response.completed` before success.
- Usage-limit, temporary service, unsupported capability, auth, network and incomplete-stream failures are separated.
- No automatic clipboard fallback.
- Password/PIN fields blocked.
- Focus-generation checks prevent wrong-app insertion.
- 2-minute bounded WAV capture to control memory and request size.
- Recorder shutdown race fixed.
- Offline and low-storage checks before expensive work.
- State-aware onboarding with a built-in test field.
- Large touch targets, labelled controls, TalkBack-friendly status, haptic start/stop feedback.

See `docs/RED_TEAM_V2_50_PASSES.md` and `docs/TEST_MATRIX_V2.md`.

## Important UX limitation

Android does not let this app simply add a button inside Samsung Keyboard. The stable implementation is its own IME, so ordinary typing may require switching back to Samsung Keyboard. A floating launcher that preserves Samsung Keyboard is a separate experimental layer because modern Android places stricter rules on background microphone capture and overlays.

## Build

See `BUILD_AND_INSTALL.md` or run the included GitHub Actions workflow to create the debug APK.
