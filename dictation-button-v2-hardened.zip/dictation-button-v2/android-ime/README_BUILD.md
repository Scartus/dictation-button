# Android module build

Requirements:
- JDK 17
- Android SDK Platform 36
- Android Build Tools 36.0.0
- Gradle 9.4.1

From this directory:

```bash
gradle --no-daemon :app:assembleDebug
```

APK output:

`app/build/outputs/apk/debug/app-debug.apk`
