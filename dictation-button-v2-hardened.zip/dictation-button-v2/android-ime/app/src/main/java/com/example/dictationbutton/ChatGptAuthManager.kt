package com.example.dictationbutton

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Handler
import android.os.Looper
import android.util.Base64
import java.io.BufferedReader
import java.io.InputStreamReader
import java.net.InetAddress
import java.net.ServerSocket
import java.net.URLDecoder
import java.net.URLEncoder
import java.security.MessageDigest
import java.security.SecureRandom

object ChatGptAuthManager {
    private const val AUTH = "https://auth.openai.com/api/accounts/authorize"
    private const val RESOURCE = "https://api.openai.com/v1"
    private const val SCOPES = "openid profile email offline_access resource.invoke chatgpt.tokens.use.direct"
    private val rng = SecureRandom()

    fun signIn(activity: Activity, result: (Result<ChatGptSession.Tokens>) -> Unit) {
        val main = Handler(Looper.getMainLooper())
        Thread {
            var server: ServerSocket? = null
            try {
                server = ServerSocket(0, 1, InetAddress.getByName("127.0.0.1"))
                server.soTimeout = 180_000
                val redirect = "http://127.0.0.1:${server.localPort}/auth/callback"
                val state = random(32); val nonce = random(32); val verifier = random(64)
                val challenge = b64(MessageDigest.getInstance("SHA-256").digest(verifier.toByteArray(Charsets.US_ASCII)))
                val previous = ChatGptSession.load(activity)
                val registration = RegistrationStore.load(activity)
                val clientId = previous?.clientId ?: registration?.clientId ?: "dynamic_agent_client"
                val params = linkedMapOf(
                    "client_id" to clientId, "redirect_uri" to redirect, "response_type" to "code",
                    "scope" to SCOPES, "resource" to RESOURCE, "state" to state, "nonce" to nonce,
                    "code_challenge_method" to "S256", "code_challenge" to challenge,
                    "ext_agent_host_id" to ChatGptSession.hostId(activity)
                )
                if (clientId == "dynamic_agent_client") params["agent_name_hint"] = "Dictation Button"
                else {
                    if (previous?.idToken?.isNotBlank() == true) params["id_token_hint"] = previous.idToken
                    (previous?.email ?: registration?.email)?.let { params["login_hint"] = it }
                }
                val url = AUTH + "?" + params.entries.joinToString("&") { enc(it.key) + "=" + enc(it.value) }
                main.post { activity.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url))) }

                val deadline = System.currentTimeMillis() + 180_000
                var query: Map<String,String>? = null
                while (System.currentTimeMillis() < deadline && query == null) {
                    val socket = server.accept()
                    socket.use {
                        val reader = BufferedReader(InputStreamReader(it.getInputStream()))
                        val first = reader.readLine().orEmpty()
                        val target = first.split(' ').getOrNull(1).orEmpty()
                        while (true) { val line = reader.readLine() ?: break; if (line.isBlank()) break }
                        val parsed = runCatching { Uri.parse("http://127.0.0.1$target") }.getOrNull()
                        val candidate = if (parsed?.path == "/auth/callback") parsed.queryParameterNames.associateWith { k -> parsed.getQueryParameter(k).orEmpty() } else emptyMap()
                        val validState = candidate["state"] == state
                        val page = if (validState) "<html><body><h2>Authorization returned</h2><p>Return to Dictation Button to finish connecting.</p></body></html>" else "<html><body><h2>Invalid sign-in callback</h2><p>You can close this page.</p></body></html>"
                        val bytes = page.toByteArray(Charsets.UTF_8)
                        it.getOutputStream().use { out ->
                            out.write("HTTP/1.1 ${if (validState) "200 OK" else "400 Bad Request"}\r\nContent-Type: text/html; charset=utf-8\r\nContent-Length: ${bytes.size}\r\nConnection: close\r\n\r\n".toByteArray())
                            out.write(bytes)
                        }
                        if (validState) query = candidate
                    }
                }
                val callback = query ?: error("ChatGPT sign-in timed out")
                callback["error"]?.takeIf { it.isNotBlank() }?.let { error("Authorization declined: $it") }
                val code = callback["code"]?.takeIf { it.isNotBlank() } ?: error("Authorization code missing")
                val callbackClient = callback["client_id"]?.takeIf { it.isNotBlank() }
                val issuedClient = if (clientId == "dynamic_agent_client") {
                    callbackClient ?: error("OpenAI did not return an issued client ID")
                } else {
                    if (callbackClient != null && callbackClient != clientId) error("Sign-in returned a different ChatGPT client registration")
                    clientId
                }
                if (clientId == "dynamic_agent_client") {
                    // Retain the issued registration before code exchange. If the one-time code
                    // expires or exchange is interrupted, the next attempt can reuse this client.
                    RegistrationStore.save(activity, issuedClient, registration?.subject, registration?.email)
                }
                val exchange = ChatGptSession.exchangeCode(issuedClient, code, verifier, redirect)
                val idToken = exchange.getString("id_token")
                val identity = JwtVerifier.verify(idToken, issuedClient, nonce)
                val expectedSubject = previous?.subject ?: registration?.subject
                if (expectedSubject != null) require(expectedSubject == identity.subject) { "A different ChatGPT account was returned for this saved connection" }
                val tokens = ChatGptSession.tokensFromExchange(exchange, issuedClient, identity.email, identity.subject)
                ChatGptSession.save(activity, tokens)
                main.post { result(Result.success(tokens)) }
            } catch (t: Throwable) {
                main.post { result(Result.failure(t)) }
            } finally { try { server?.close() } catch (_: Throwable) {} }
        }.apply { name = "ChatGptOAuth"; start() }
    }

    private fun random(bytes: Int): String = ByteArray(bytes).also { rng.nextBytes(it) }.let { b64(it) }
    private fun b64(bytes: ByteArray) = Base64.encodeToString(bytes, Base64.URL_SAFE or Base64.NO_WRAP or Base64.NO_PADDING)
    private fun enc(s: String) = URLEncoder.encode(s, "UTF-8")
}
