package com.example.dictationbutton

import android.content.Context
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.util.UUID

object ChatGptSession {
    private const val TOKEN_URL = "https://auth.openai.com/api/accounts/oauth/token"
    private const val DISCOVERY_URL = "https://auth.openai.com/.well-known/openid-configuration"
    private const val RESOURCE = "https://api.openai.com/v1"
    private const val HOST_PREFS = "dictation_host"
    private const val HOST_KEY = "host_id"

    data class Tokens(
        val accessToken: String,
        val refreshToken: String,
        val idToken: String,
        val clientId: String,
        val scope: String,
        val expiresAtMs: Long,
        val earliestRefreshAtMs: Long,
        val email: String?,
        val subject: String?
    )

    fun hostId(context: Context): String {
        val p = context.getSharedPreferences(HOST_PREFS, Context.MODE_PRIVATE)
        p.getString(HOST_KEY, null)?.let { return it }
        val created = "urn:uuid:${UUID.randomUUID()}"
        p.edit().putString(HOST_KEY, created).commit()
        return created
    }

    fun load(context: Context): Tokens? {
        val j = SecureStore.read(context)
        val access = j.optString("access_token")
        val refresh = j.optString("refresh_token")
        val client = j.optString("client_id")
        if (access.isBlank() || refresh.isBlank() || client.isBlank()) return null
        return Tokens(access, refresh, j.optString("id_token"), client, j.optString("scope"),
            j.optLong("expires_at_ms"), j.optLong("earliest_refresh_at_ms"),
            j.optString("email").ifBlank { null }, j.optString("subject").ifBlank { null })
    }

    fun save(context: Context, t: Tokens) {
        SecureStore.write(context, JSONObject().apply {
            put("access_token", t.accessToken); put("refresh_token", t.refreshToken); put("id_token", t.idToken)
            put("client_id", t.clientId); put("scope", t.scope); put("expires_at_ms", t.expiresAtMs)
            put("earliest_refresh_at_ms", t.earliestRefreshAtMs)
            if (t.email != null) put("email", t.email)
            if (t.subject != null) put("subject", t.subject)
        })
        RegistrationStore.save(context, t.clientId, t.subject, t.email)
    }

    fun clear(context: Context) = SecureStore.clear(context)
    fun isConnected(context: Context): Boolean = load(context)?.scope?.split(' ')?.contains("chatgpt.tokens.use.direct") == true

    @Synchronized
    fun validAccessToken(context: Context, forceRefresh: Boolean = false): String {
        val t = load(context) ?: error("Not connected to ChatGPT")
        val now = System.currentTimeMillis()
        if (!forceRefresh && t.expiresAtMs > now + 120_000) return t.accessToken
        if (!forceRefresh && now < t.earliestRefreshAtMs && t.expiresAtMs > now + 15_000) return t.accessToken
        return refresh(context, t).accessToken
    }

    @Synchronized
    private fun refresh(context: Context, old: Tokens): Tokens {
        val body = form(mapOf("grant_type" to "refresh_token", "refresh_token" to old.refreshToken, "client_id" to old.clientId, "resource" to RESOURCE))
        val j = postForm(TOKEN_URL, body)
        val scope = j.optString("scope", old.scope)
        require(scope.split(' ').contains("chatgpt.tokens.use.direct")) { "ChatGPT plan permission is no longer granted" }
        val now = System.currentTimeMillis()
        val updated = Tokens(
            j.getString("access_token"), j.optString("refresh_token", old.refreshToken), j.optString("id_token", old.idToken),
            old.clientId, scope, now + j.optLong("expires_in", 3600) * 1000,
            parseEpoch(j.opt("earliest_refresh_at"), now), old.email, old.subject
        )
        save(context, updated)
        return updated
    }

    fun exchangeCode(clientId: String, code: String, verifier: String, redirectUri: String): JSONObject = postForm(
        TOKEN_URL,
        form(mapOf("grant_type" to "authorization_code", "client_id" to clientId, "code" to code,
            "code_verifier" to verifier, "redirect_uri" to redirectUri, "resource" to RESOURCE))
    )

    fun tokensFromExchange(exchange: JSONObject, clientId: String, email: String?, subject: String?): Tokens {
        val scope = exchange.getString("scope")
        require(scope.split(' ').contains("chatgpt.tokens.use.direct")) { "ChatGPT plan usage was not approved" }
        val now = System.currentTimeMillis()
        return Tokens(exchange.getString("access_token"), exchange.getString("refresh_token"), exchange.getString("id_token"), clientId,
            scope, now + exchange.optLong("expires_in", 3600) * 1000,
            parseEpoch(exchange.opt("earliest_refresh_at"), now), email, subject)
    }

    fun revokeAndClear(context: Context): Boolean {
        val t = load(context) ?: run { clear(context); return true }
        var confirmed = false
        try {
            val discovery = getJson(DISCOVERY_URL)
            val revokeUrl = discovery.optString("revocation_endpoint").takeIf { it.startsWith("https://auth.openai.com/") }
                ?: error("OpenAI revocation endpoint unavailable")
            val body = form(mapOf("token" to t.refreshToken, "token_type_hint" to "refresh_token", "client_id" to t.clientId))
            postFormAllowEmpty(revokeUrl, body)
            confirmed = true
        } finally {
            clear(context)
        }
        return confirmed
    }

    private fun parseEpoch(value: Any?, fallback: Long): Long {
        val n = when (value) { is Number -> value.toLong(); is String -> value.toLongOrNull() ?: return fallback; else -> return fallback }
        return if (n > 10_000_000_000L) n else n * 1000
    }

    private fun form(values: Map<String, String>) = values.entries.joinToString("&") { "${enc(it.key)}=${enc(it.value)}" }
    private fun enc(s: String) = URLEncoder.encode(s, "UTF-8")

    private fun getJson(url: String): JSONObject {
        val c = URL(url).openConnection() as HttpURLConnection
        c.connectTimeout = 15_000; c.readTimeout = 20_000; c.setRequestProperty("Accept", "application/json")
        return try {
            val code = c.responseCode
            val text = (if (code in 200..299) c.inputStream else c.errorStream)?.bufferedReader()?.use { it.readText() }.orEmpty()
            if (code !in 200..299) error("OpenAI discovery error $code")
            JSONObject(text)
        } finally { c.disconnect() }
    }

    private fun postForm(url: String, body: String): JSONObject {
        val text = postFormRaw(url, body)
        return JSONObject(text)
    }

    private fun postFormAllowEmpty(url: String, body: String) { postFormRaw(url, body) }

    private fun postFormRaw(url: String, body: String): String {
        val c = URL(url).openConnection() as HttpURLConnection
        c.requestMethod = "POST"; c.connectTimeout = 15_000; c.readTimeout = 30_000; c.doOutput = true
        c.setRequestProperty("Content-Type", "application/x-www-form-urlencoded")
        c.setRequestProperty("Accept", "application/json")
        return try {
            c.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }
            val code = c.responseCode
            val text = (if (code in 200..299) c.inputStream else c.errorStream)?.bufferedReader()?.use { it.readText() }.orEmpty()
            if (code !in 200..299) error("OpenAI authorization error $code: ${text.take(300)}")
            text
        } finally { c.disconnect() }
    }
}
