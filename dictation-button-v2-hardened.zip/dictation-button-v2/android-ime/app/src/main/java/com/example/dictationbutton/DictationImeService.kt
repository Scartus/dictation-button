package com.example.dictationbutton

import android.Manifest
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.inputmethodservice.InputMethodService
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.net.Uri
import android.os.Handler
import android.os.Looper
import android.text.InputType
import android.view.View
import android.view.inputmethod.EditorInfo
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import java.io.File
import java.util.concurrent.atomic.AtomicLong

class DictationImeService : InputMethodService() {
    private enum class State { IDLE, STARTING, RECORDING, STOPPING, TRANSCRIBING }

    private val main = Handler(Looper.getMainLooper())
    private val generation = AtomicLong(0)
    @Volatile private var state = State.IDLE
    private var recorder: WavRecorder? = null
    private var session: RecordingSession? = null
    private var pendingTranscript: String? = null
    private var failedAudio: File? = null // encrypted .enc recovery blob
    private var retryEncryptedSource: File? = null
    private var recordingStartedAt = 0L
    private var showManageUsage = false

    private lateinit var status: TextView
    private lateinit var timer: TextView
    private lateinit var mic: Button
    private lateinit var cancel: Button
    private lateinit var recoveryRow: LinearLayout
    private lateinit var retryAudio: Button
    private lateinit var manageUsage: Button
    private lateinit var deleteAudio: Button

    private val timerTick = object : Runnable {
        override fun run() {
            if (state != State.RECORDING || !::timer.isInitialized) return
            val elapsed = ((System.currentTimeMillis() - recordingStartedAt) / 1000).coerceAtLeast(0)
            timer.text = "%d:%02d".format(elapsed / 60, elapsed % 60)
            main.postDelayed(this, 1000)
        }
    }

    override fun onCreate() {
        super.onCreate()
        EncryptedAudioStore.cleanupStaleCache(this)
    }

    override fun onCreateInputView(): View {
        val v = layoutInflater.inflate(R.layout.ime_view, null)
        status = v.findViewById(R.id.status)
        timer = v.findViewById(R.id.timer)
        mic = v.findViewById(R.id.micButton)
        cancel = v.findViewById(R.id.cancelButton)
        recoveryRow = v.findViewById(R.id.recoveryRow)
        retryAudio = v.findViewById(R.id.retryAudioButton)
        manageUsage = v.findViewById(R.id.manageUsageButton)
        deleteAudio = v.findViewById(R.id.deleteAudioButton)
        pendingTranscript = RecoveryTextStore.load(this)
        failedAudio = EncryptedAudioStore.latest(this)

        mic.setOnClickListener {
            when (state) {
                State.IDLE -> beginRecording()
                State.RECORDING -> finishRecording()
                else -> Unit
            }
        }
        cancel.setOnClickListener { cancelCurrent("Cancelled. No text will be inserted.") }
        v.findViewById<Button>(R.id.nextImeButton).setOnClickListener { switchToNextInputMethod(false) }
        v.findViewById<Button>(R.id.insertButton).setOnClickListener { insertPending() }
        v.findViewById<Button>(R.id.copyButton).setOnClickListener { copyPending() }
        v.findViewById<Button>(R.id.discardTextButton).setOnClickListener { discardPending() }
        retryAudio.setOnClickListener { retryFailedAudio() }
        deleteAudio.setOnClickListener { deleteSavedAudio() }
        manageUsage.setOnClickListener { openUsageSettings() }
        render()
        return v
    }

    override fun onStartInput(attribute: EditorInfo?, restarting: Boolean) {
        super.onStartInput(attribute, restarting)
        if (!restarting) generation.incrementAndGet()
        main.post { render() }
    }

    override fun onFinishInput() {
        if (state == State.RECORDING || state == State.STARTING) cancelCurrent("Recording cancelled because the text field closed.")
        generation.incrementAndGet()
        super.onFinishInput()
    }

    override fun onWindowHidden() {
        if (state == State.RECORDING || state == State.STARTING) cancelCurrent("Recording cancelled because the keyboard was hidden.")
        super.onWindowHidden()
    }

    override fun onDestroy() {
        cancelCurrent(null)
        main.removeCallbacks(timerTick)
        super.onDestroy()
    }

    private fun beginRecording() {
        if (state != State.IDLE) return
        showManageUsage = false
        if (!ChatGptSession.isConnected(this)) {
            setStatus("Open Dictation Button and connect ChatGPT first.")
            return
        }
        if (cacheDir.usableSpace < 25_000_000L) {
            setStatus("Not enough free storage for a safe recording. Free some space and try again.")
            return
        }
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            setStatus("Open Dictation Button and allow microphone access first.")
            return
        }
        val info = currentInputEditorInfo
        if (info == null || isPasswordField(info.inputType)) {
            setStatus("Dictation is disabled for password and PIN fields.")
            return
        }
        state = State.STARTING
        render()
        val f = File(cacheDir, "dictation-${System.currentTimeMillis()}.wav")
        val s = RecordingSession(editorGeneration = generation.get(), packageName = info.packageName, fieldId = info.fieldId, file = f)
        session = s
        val r = WavRecorder { main.post { if (state == State.RECORDING) finishRecording() } }
        recorder = r
        try {
            r.start(f)
            recordingStartedAt = System.currentTimeMillis()
            state = State.RECORDING
            timer.text = "0:00"
            main.removeCallbacks(timerTick)
            main.post(timerTick)
            mic.performHapticFeedback(android.view.HapticFeedbackConstants.KEYBOARD_TAP)
            render()
        } catch (t: Throwable) {
            f.delete(); session = null; recorder = null; state = State.IDLE
            setStatus("Could not start the microphone. ${t.message ?: "Try again."}")
            render()
        }
    }

    private fun finishRecording() {
        if (state != State.RECORDING) return
        state = State.STOPPING
        main.removeCallbacks(timerTick)
        mic.performHapticFeedback(android.view.HapticFeedbackConstants.KEYBOARD_TAP)
        render()
        val s = session ?: return fail("Recording session was lost.")
        val r = recorder ?: return fail("Recorder was lost.")
        val err = r.stop()
        if (System.currentTimeMillis() - recordingStartedAt < 300) {
            s.file.delete()
            return fail("Recording was too short. Tap Dictate and speak, then Stop.")
        }
        if (err != null) {
            preserveFailed(s.file)
            return fail("Recording could not be finalized. It was encrypted and kept for Retry.", delete = false)
        }
        if (!s.file.exists() || s.file.length() < 1000) return fail("Recording was empty or too short.")
        if (!hasUsableNetwork()) {
            preserveFailed(s.file)
            return fail("No internet connection. The recording was encrypted and saved; tap Retry when you're online.", delete = false)
        }
        transcribeSession(s, allowAutoInsert = true)
    }

    private fun transcribeSession(s: RecordingSession, allowAutoInsert: Boolean) {
        state = State.TRANSCRIBING
        render()
        Thread {
            try {
                val result = OpenAiPlanClient.transcribe(this, s.file)
                main.post { onTranscript(s, result.text, allowAutoInsert) }
            } catch (t: Throwable) {
                main.post { onTranscriptionFailure(s, t, isRetry = !allowAutoInsert) }
            }
        }.apply { name = "DictationTranscribe"; start() }
    }

    private fun onTranscriptionFailure(s: RecordingSession, t: Throwable, isRetry: Boolean) {
        if (session?.id != s.id) {
            s.file.delete()
            return
        }
        if (!isRetry) preserveFailed(s.file) else s.file.delete()
        state = State.IDLE; recorder = null; session = null
        val p = t as? OpenAiPlanClient.PlanException
        showManageUsage = p?.kind == OpenAiPlanClient.ErrorKind.USAGE_LIMIT
        val requestSuffix = p?.requestId?.let { " Request ID: $it" }.orEmpty()
        val message = when (p?.kind) {
            OpenAiPlanClient.ErrorKind.USAGE_LIMIT -> "ChatGPT plan usage limit reached. Your recording is still saved. Manage usage, then Retry later."
            OpenAiPlanClient.ErrorKind.AUTH -> "ChatGPT connection needs attention. Open Dictation Button, reconnect, then Retry the saved recording."
            OpenAiPlanClient.ErrorKind.TEMPORARY -> "ChatGPT plan usage is temporarily unavailable. Your recording is saved for Retry."
            OpenAiPlanClient.ErrorKind.NETWORK -> "The connection was interrupted. Your recording is saved for Retry."
            OpenAiPlanClient.ErrorKind.INCOMPLETE -> "The transcription did not finish. No partial text was inserted; your recording is saved for Retry."
            else -> "Transcription failed. Your recording is saved for Retry: ${t.message ?: "unknown error"}"
        }
        setStatus(message + requestSuffix, announce = true)
        render()
    }

    private fun onTranscript(s: RecordingSession, text: String, allowAutoInsert: Boolean) {
        if (session?.id != s.id || state != State.TRANSCRIBING) {
            s.file.delete()
            return
        }
        pendingTranscript = text
        RecoveryTextStore.save(this, text)
        val info = currentInputEditorInfo
        val sameEditor = allowAutoInsert && generation.get() == s.editorGeneration && info != null &&
            info.packageName == s.packageName && (s.fieldId == 0 || info.fieldId == 0 || info.fieldId == s.fieldId)
        val inserted = if (sameEditor && !isPasswordField(info!!.inputType)) {
            currentInputConnection?.commitText(text, 1) == true
        } else false

        s.file.delete()
        EncryptedAudioStore.delete(retryEncryptedSource)
        retryEncryptedSource = null
        failedAudio = EncryptedAudioStore.latest(this)
        state = State.IDLE; recorder = null; session = null
        if (inserted) {
            pendingTranscript = null
            RecoveryTextStore.clear(this)
            setStatus("Inserted.", announce = true)
        } else {
            setStatus(if (allowAutoInsert) "Focus changed or insertion failed. Transcript kept here for recovery." else "Recovered transcript ready. Tap Insert or Copy.", announce = true)
        }
        render()
    }

    private fun retryFailedAudio() {
        if (state != State.IDLE) return
        val encrypted = failedAudio?.takeIf { it.exists() } ?: EncryptedAudioStore.latest(this)
        if (encrypted == null) {
            setStatus("No saved recording to retry.")
            render(); return
        }
        if (!ChatGptSession.isConnected(this)) {
            setStatus("Reconnect ChatGPT in the Dictation Button app first.")
            return
        }
        if (!hasUsableNetwork()) {
            setStatus("No internet connection yet. The encrypted recording is still safe on this phone.")
            return
        }
        val temp = try { EncryptedAudioStore.decryptToCache(this, encrypted) }
        catch (t: Throwable) {
            setStatus("The saved recording could not be decrypted. It may be damaged.")
            return
        }
        retryEncryptedSource = encrypted
        val info = currentInputEditorInfo
        val s = RecordingSession(editorGeneration = generation.get(), packageName = info?.packageName, fieldId = info?.fieldId ?: 0, file = temp)
        session = s; recorder = null
        transcribeSession(s, allowAutoInsert = false)
    }

    private fun preserveFailed(src: File) {
        if (!src.exists()) return
        try {
            failedAudio = EncryptedAudioStore.save(this, src)
        } catch (_: Throwable) {
            src.delete()
            failedAudio = null
            setStatus("Could not safely save the failed recording; temporary audio was deleted.", announce = true)
        }
    }

    private fun insertPending() {
        val text = pendingTranscript ?: return
        val info = currentInputEditorInfo
        if (info == null || isPasswordField(info.inputType)) {
            setStatus("Cannot insert into this field.")
            return
        }
        if (currentInputConnection?.commitText(text, 1) == true) {
            pendingTranscript = null
            RecoveryTextStore.clear(this)
            setStatus("Recovered text inserted.", announce = true)
            render()
        }
    }

    private fun copyPending() {
        pendingTranscript?.let {
            (getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager)
                .setPrimaryClip(ClipData.newPlainText("dictation", it))
            setStatus("Recovered text copied to the clipboard.", announce = true)
        }
    }

    private fun discardPending() {
        pendingTranscript = null
        RecoveryTextStore.clear(this)
        setStatus("Recovered text discarded.", announce = true)
        render()
    }

    private fun deleteSavedAudio() {
        EncryptedAudioStore.delete(failedAudio)
        failedAudio = EncryptedAudioStore.latest(this)
        retryEncryptedSource = null
        setStatus("Saved recording deleted.", announce = true)
        render()
    }

    private fun cancelCurrent(message: String?) {
        val s = session
        try { recorder?.cancel() } catch (_: Throwable) {}
        if (state == State.RECORDING || state == State.STARTING || state == State.STOPPING) s?.file?.delete()
        // During TRANSCRIBING the network operation may already have reached OpenAI. Clearing the
        // session guarantees any late result cannot be inserted into another editor.
        recorder = null; session = null; state = State.IDLE
        main.removeCallbacks(timerTick)
        main.post {
            if (::status.isInitialized) {
                timer.text = ""
                if (message != null) setStatus(message, announce = true)
                render()
            }
        }
    }

    private fun fail(msg: String, delete: Boolean = true) {
        if (delete) session?.file?.delete()
        state = State.IDLE; recorder = null; session = null
        setStatus(msg, announce = true)
        render()
    }

    private fun render() {
        if (!::mic.isInitialized) return
        mic.isEnabled = state == State.IDLE || state == State.RECORDING
        cancel.isEnabled = state != State.IDLE
        mic.text = when (state) {
            State.IDLE -> "Dictate"
            State.STARTING -> "Starting…"
            State.RECORDING -> "Stop recording"
            State.STOPPING -> "Stopping…"
            State.TRANSCRIBING -> "Transcribing…"
        }
        mic.contentDescription = when (state) {
            State.IDLE -> "Start dictation"
            State.RECORDING -> "Stop recording and transcribe"
            else -> mic.text
        }
        if (state == State.RECORDING) setStatus("Recording. Tap Stop recording when finished.")
        else if (state == State.TRANSCRIBING) setStatus("Transcribing using your ChatGPT plan. No text is inserted until completion.")
        if (state != State.RECORDING) timer.text = ""
        recoveryRow.visibility = if (pendingTranscript != null) View.VISIBLE else View.GONE
        failedAudio = failedAudio?.takeIf { it.exists() } ?: EncryptedAudioStore.latest(this)
        retryAudio.visibility = if (failedAudio != null) View.VISIBLE else View.GONE
        deleteAudio.visibility = if (failedAudio != null) View.VISIBLE else View.GONE
        manageUsage.visibility = if (showManageUsage) View.VISIBLE else View.GONE
    }

    private fun setStatus(message: String, announce: Boolean = false) {
        if (!::status.isInitialized) return
        if (status.text.toString() == message) return
        status.text = message
        if (announce) status.announceForAccessibility(message)
    }

    private fun hasUsableNetwork(): Boolean {
        val cm = getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        val n = cm.activeNetwork ?: return false
        val caps = cm.getNetworkCapabilities(n) ?: return false
        return caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET) &&
            caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_VALIDATED)
    }

    private fun openUsageSettings() {
        val i = Intent(Intent.ACTION_VIEW, Uri.parse("https://chatgpt.com/settings/usage")).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        runCatching { startActivity(i) }.onFailure { setStatus("Open ChatGPT Settings → Usage to manage your plan usage.", announce = true) }
    }

    private fun isPasswordField(inputType: Int): Boolean {
        val k = inputType and InputType.TYPE_MASK_CLASS
        val v = inputType and InputType.TYPE_MASK_VARIATION
        return when (k) {
            InputType.TYPE_CLASS_TEXT -> v == InputType.TYPE_TEXT_VARIATION_PASSWORD ||
                v == InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD ||
                v == InputType.TYPE_TEXT_VARIATION_WEB_PASSWORD
            InputType.TYPE_CLASS_NUMBER -> v == InputType.TYPE_NUMBER_VARIATION_PASSWORD
            else -> false
        }
    }
}
