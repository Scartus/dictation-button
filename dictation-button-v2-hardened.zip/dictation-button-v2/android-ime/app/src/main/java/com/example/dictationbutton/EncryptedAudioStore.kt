package com.example.dictationbutton

import android.content.Context
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import java.io.File
import java.security.KeyStore
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec

object EncryptedAudioStore {
    private const val ALIAS = "dictation_button_failed_audio_v2"
    private const val IV_BYTES = 12
    private const val MAX_ITEMS = 1

    fun save(context: Context, plaintext: File): File {
        val dir = File(context.filesDir, "recovery_audio").apply { mkdirs() }
        val out = File(dir, "failed-${System.currentTimeMillis()}.enc")
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(Cipher.ENCRYPT_MODE, key())
        out.outputStream().use { stream ->
            stream.write(cipher.iv)
            javax.crypto.CipherOutputStream(stream, cipher).use { encrypted ->
                plaintext.inputStream().use { it.copyTo(encrypted) }
            }
        }
        plaintext.delete()
        cleanup(dir)
        return out
    }

    fun latest(context: Context): File? {
        val dir = File(context.filesDir, "recovery_audio")
        val cutoff = System.currentTimeMillis() - 24 * 60 * 60 * 1000L
        dir.listFiles()?.filter { it.extension == "enc" && it.lastModified() < cutoff }?.forEach { it.delete() }
        return dir.listFiles()?.filter { it.extension == "enc" }?.maxByOrNull { it.lastModified() }
    }

    fun decryptToCache(context: Context, encrypted: File): File {
        require(encrypted.exists()) { "Saved recording is missing" }
        val tmp = File(context.cacheDir, "retry-${System.currentTimeMillis()}.wav")
        encrypted.inputStream().use { input ->
            val iv = ByteArray(IV_BYTES)
            require(input.read(iv) == IV_BYTES) { "Saved recording is damaged" }
            val cipher = Cipher.getInstance("AES/GCM/NoPadding")
            cipher.init(Cipher.DECRYPT_MODE, key(), GCMParameterSpec(128, iv))
            javax.crypto.CipherInputStream(input, cipher).use { decrypted ->
                tmp.outputStream().use { decrypted.copyTo(it) }
            }
        }
        return tmp
    }

    fun delete(file: File?) { try { file?.delete() } catch (_: Throwable) {} }

    fun cleanupStaleCache(context: Context) {
        val cutoff = System.currentTimeMillis() - 30 * 60 * 1000L
        context.cacheDir.listFiles()?.filter {
            (it.name.startsWith("dictation-") || it.name.startsWith("retry-")) && it.lastModified() < cutoff
        }?.forEach { it.delete() }
    }

    private fun cleanup(dir: File) {
        dir.listFiles()?.filter { it.extension == "enc" }
            ?.sortedByDescending { it.lastModified() }?.drop(MAX_ITEMS)?.forEach { it.delete() }
    }

    private fun key(): SecretKey {
        val ks = KeyStore.getInstance("AndroidKeyStore").apply { load(null) }
        (ks.getKey(ALIAS, null) as? SecretKey)?.let { return it }
        val kg = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore")
        kg.init(KeyGenParameterSpec.Builder(ALIAS, KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT)
            .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
            .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
            .build())
        return kg.generateKey()
    }
}
