package com.example.dictationbutton

import android.util.Base64
import org.json.JSONArray
import org.json.JSONObject
import java.math.BigInteger
import java.net.HttpURLConnection
import java.net.URL
import java.security.KeyFactory
import java.security.Signature
import java.security.spec.RSAPublicKeySpec

object JwtVerifier {
    private const val JWKS = "https://auth.openai.com/.well-known/jwks.json"
    private const val ISSUER = "https://auth.openai.com"

    data class Identity(val subject: String, val email: String?)

    fun verify(idToken: String, expectedClientId: String, expectedNonce: String): Identity {
        val parts = idToken.split('.')
        require(parts.size == 3) { "Malformed ID token" }
        val header = JSONObject(String(b64(parts[0]), Charsets.UTF_8))
        val payload = JSONObject(String(b64(parts[1]), Charsets.UTF_8))
        require(header.optString("alg") == "RS256") { "Unexpected ID-token algorithm" }
        val kid = header.getString("kid")
        val jwk = fetchKeys().firstOrNull { it.optString("kid") == kid } ?: error("OpenAI signing key not found")
        val n = BigInteger(1, b64(jwk.getString("n"))); val e = BigInteger(1, b64(jwk.getString("e")))
        val pub = KeyFactory.getInstance("RSA").generatePublic(RSAPublicKeySpec(n, e))
        val sig = Signature.getInstance("SHA256withRSA"); sig.initVerify(pub); sig.update("${parts[0]}.${parts[1]}".toByteArray(Charsets.US_ASCII))
        require(sig.verify(b64(parts[2]))) { "Invalid ID-token signature" }
        require(payload.optString("iss") == ISSUER) { "Unexpected ID-token issuer" }
        require(audienceContains(payload.opt("aud"), expectedClientId)) { "ID token is for a different client" }
        val now = System.currentTimeMillis()
        require(payload.optLong("exp") * 1000 > now - 30_000) { "ID token expired" }
        val nbf = payload.optLong("nbf", 0)
        require(nbf == 0L || nbf * 1000 <= now + 30_000) { "ID token is not valid yet" }
        require(payload.optString("nonce") == expectedNonce) { "ID-token nonce mismatch" }
        val sub = payload.getString("sub")
        return Identity(sub, payload.optString("email").ifBlank { null })
    }

    private fun audienceContains(aud: Any?, expected: String): Boolean = when (aud) {
        is String -> aud == expected
        is JSONArray -> (0 until aud.length()).any { aud.optString(it) == expected }
        else -> false
    }

    private fun fetchKeys(): List<JSONObject> {
        val c = URL(JWKS).openConnection() as HttpURLConnection
        c.connectTimeout = 10_000; c.readTimeout = 10_000; c.setRequestProperty("Accept", "application/json")
        val code = c.responseCode
        val text = (if (code in 200..299) c.inputStream else c.errorStream)?.bufferedReader()?.use { it.readText() }.orEmpty()
        c.disconnect(); if (code !in 200..299) error("Could not load OpenAI signing keys")
        val a = JSONObject(text).getJSONArray("keys")
        return (0 until a.length()).map { a.getJSONObject(it) }
    }

    private fun b64(s: String): ByteArray = Base64.decode(s, Base64.URL_SAFE or Base64.NO_WRAP or Base64.NO_PADDING)
}
