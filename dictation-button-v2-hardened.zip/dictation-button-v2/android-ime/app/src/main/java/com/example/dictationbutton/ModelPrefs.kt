package com.example.dictationbutton
import android.content.Context
object ModelPrefs {
    private const val P="dictation_model"; private const val K="last_success"
    fun get(c:Context)=c.getSharedPreferences(P,Context.MODE_PRIVATE).getString(K,null)
    fun set(c:Context,v:String)=c.getSharedPreferences(P,Context.MODE_PRIVATE).edit().putString(K,v).apply()
    fun clear(c:Context)=c.getSharedPreferences(P,Context.MODE_PRIVATE).edit().remove(K).apply()
}
