package com.example.dictationbutton

import android.content.Context
import android.util.Base64
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.net.HttpURLConnection
import java.net.URL

object OpenAiPlanClient {
    private const val API = "https://api.openai.com/v1"
    private val preferred = listOf("gpt-6.1-sol", "gpt-5.6-sol", "gpt-6-luna")

    enum class ErrorKind { AUTH, USAGE_LIMIT, TEMPORARY, UNSUPPORTED, NETWORK, INCOMPLETE, UNKNOWN }
    class PlanException(
        val kind: ErrorKind,
        message: String,
        val status: Int? = null,
        val requestId: String? = null,
        val apiCode: String? = null
    ) : RuntimeException(message)

    data class Result(val text: String, val model: String)

    fun transcribe(context: Context, file: File): Result {
        require(file.exists() && file.length() in 45..20_000_000) { "Audio file is empty or too large" }
        var token = ChatGptSession.validAccessToken(context)
        val cached = ModelPrefs.get(context)
        if (!cached.isNullOrBlank()) {
            try {
                return Result(callResponses(token, cached, file), cached)
            } catch (t: PlanException) {
                if (t.kind == ErrorKind.AUTH) {
                    token = ChatGptSession.validAccessToken(context, forceRefresh = true)
                    return Result(callResponses(token, cached, file), cached)
                }
                if (t.kind != ErrorKind.UNSUPPORTED) throw t
                ModelPrefs.clear(context)
            }
        }

        var models = try { listModels(token) } catch (t: PlanException) {
            if (t.kind == ErrorKind.AUTH) {
                token = ChatGptSession.validAccessToken(context, forceRefresh = true)
                listModels(token)
            } else throw t
        }
        val candidates = (preferred.filter { it in models } +
            models.filter { it.contains("sol") || it.contains("luna") } + models).distinct().take(10)
        require(candidates.isNotEmpty()) { "No compatible ChatGPT model is available for this account" }

        var last: Throwable? = null
        for (model in candidates) {
            try {
                val text = callResponses(token, model, file)
                ModelPrefs.set(context, model)
                return Result(text, model)
            } catch (t: PlanException) {
                if (t.kind == ErrorKind.AUTH) {
                    token = ChatGptSession.validAccessToken(context, forceRefresh = true)
                    val text = callResponses(token, model, file)
                    ModelPrefs.set(context, model)
                    return Result(text, model)
                }
                last = t
                if (t.kind != ErrorKind.UNSUPPORTED) throw t
            }
        }
        throw last ?: IllegalStateException("No available model accepted audio input")
    }

    private fun listModels(token: String): List<String> {
        val c = URL("$API/models").openConnection() as HttpURLConnection
        c.connectTimeout = 12_000
        c.readTimeout = 20_000
        c.setRequestProperty("Authorization", "Bearer $token")
        c.setRequestProperty("Accept", "application/json")
        return try {
            val code = c.responseCode
            val text = (if (code in 200..299) c.inputStream else c.errorStream)?.bufferedReader()?.use { it.readText() }.orEmpty()
            if (code !in 200..299) throw classifyHttp(code, text, c.getHeaderField("x-request-id"), "Could not list ChatGPT models")
            val root = JSONObject(text)
            val arr = root.optJSONArray("models") ?: root.optJSONArray("data") ?: JSONArray()
            (0 until arr.length()).mapNotNull { i ->
                val o = arr.optJSONObject(i) ?: return@mapNotNull null
                val visible = o.optString("visibility")
                val slug = o.optString("slug", o.optString("id"))
                if (slug.isNotBlank() && (visible.isBlank() || visible == "list")) slug else null
            }
        } catch (t: PlanException) { throw t }
        catch (t: Throwable) { throw PlanException(ErrorKind.NETWORK, "Could not reach OpenAI: ${t.message ?: "network error"}") }
        finally { c.disconnect() }
    }

    private fun callResponses(token: String, model: String, file: File): String {
        val audio = Base64.encodeToString(file.readBytes(), Base64.NO_WRAP)
        val body = JSONObject().apply {
            put("model", model)
            put("store", false)
            put("stream", true)
            put("instructions", "Transcribe the user's audio faithfully. Return only the spoken words as plain text. Preserve numbers, names, medical terms, hesitations, and language switching. Do not summarize, correct facts, add units, answer questions, or rewrite the wording. Add ordinary punctuation only where it reflects the speech.")
            put("input", JSONArray().put(JSONObject().apply {
                put("role", "user")
                put("content", JSONArray().put(JSONObject().apply {
                    put("type", "input_audio")
                    put("input_audio", JSONObject().put("data", audio).put("format", "wav"))
                }))
            }))
        }.toString()

        val c = URL("$API/responses").openConnection() as HttpURLConnection
        c.requestMethod = "POST"
        c.connectTimeout = 15_000
        c.readTimeout = 120_000
        c.doOutput = true
        c.setRequestProperty("Authorization", "Bearer $token")
        c.setRequestProperty("Content-Type", "application/json")
        c.setRequestProperty("Accept", "text/event-stream")

        try {
            c.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }
            val status = c.responseCode
            val requestId = c.getHeaderField("x-request-id")
            if (status !in 200..299) {
                val err = c.errorStream?.bufferedReader()?.use { it.readText() }.orEmpty()
                throw classifyHttp(status, err, requestId, "Responses request failed")
            }

            val out = StringBuilder()
            var completedText: String? = null
            var completed = false
            c.inputStream.bufferedReader().useLines { lines ->
                lines.forEach { line ->
                    if (!line.startsWith("data:")) return@forEach
                    val data = line.removePrefix("data:").trim()
                    if (data.isBlank() || data == "[DONE]") return@forEach
                    val event = runCatching { JSONObject(data) }.getOrNull() ?: return@forEach
                    when (event.optString("type")) {
                        "response.output_text.delta" -> out.append(event.optString("delta"))
                        "response.completed" -> {
                            completed = true
                            if (out.isEmpty()) completedText = extractText(event.optJSONObject("response"))
                        }
                        "response.failed" -> {
                            val e = event.optJSONObject("response")?.optJSONObject("error")
                            throw classifyApiError(e, requestId)
                        }
                        "response.incomplete" -> throw PlanException(ErrorKind.INCOMPLETE, "Transcription did not complete. Audio was kept for Retry.", requestId = requestId)
                        "error" -> throw classifyApiError(event.optJSONObject("error"), requestId)
                    }
                }
            }
            if (!completed) throw PlanException(ErrorKind.INCOMPLETE, "The transcription stream ended before completion. Audio was kept for Retry.", requestId = requestId)
            val text = (if (out.isNotEmpty()) out.toString() else completedText.orEmpty()).trim()
            if (text.isEmpty()) throw PlanException(ErrorKind.INCOMPLETE, "OpenAI completed the request but returned an empty transcript.", requestId = requestId)
            return text
        } catch (t: PlanException) { throw t }
        catch (t: Throwable) { throw PlanException(ErrorKind.NETWORK, "Network interrupted during transcription: ${t.message ?: "connection lost"}") }
        finally { c.disconnect() }
    }

    private fun classifyHttp(status: Int, body: String, requestId: String?, prefix: String): PlanException {
        val root = runCatching { JSONObject(body) }.getOrNull()
        val error = root?.optJSONObject("error")
        val code = error?.optString("code")?.ifBlank { null }
        val message = error?.optString("message")?.ifBlank { null }
            ?: root?.optString("detail")?.ifBlank { null }
            ?: body.take(240).ifBlank { "$prefix ($status)" }
        return classify(status, code, message, requestId)
    }

    private fun classifyApiError(error: JSONObject?, requestId: String?): PlanException {
        val code = error?.optString("code")?.ifBlank { null }
        val message = error?.optString("message")?.ifBlank { null } ?: "The response failed"
        return classify(null, code, message, requestId)
    }

    private fun classify(status: Int?, code: String?, message: String, requestId: String?): PlanException {
        val kind = when {
            code == "subscription_sharing_usage_limit_exceeded" -> ErrorKind.USAGE_LIMIT
            code in setOf("subscription_sharing_usage_unavailable", "subscription_sharing_user_unavailable") -> ErrorKind.TEMPORARY
            code in setOf("subscription_sharing_unsupported_capability", "subscription_sharing_route_not_supported") -> ErrorKind.UNSUPPORTED
            code in setOf("subscription_sharing_invalid_user", "chatpass_v2_scope_not_authorized", "chatpass_v2_invalid_authorization_context") -> ErrorKind.AUTH
            status == 401 -> ErrorKind.AUTH
            status == 429 -> ErrorKind.USAGE_LIMIT
            status == 503 -> ErrorKind.TEMPORARY
            status in listOf(400, 404, 422) -> ErrorKind.UNSUPPORTED
            else -> ErrorKind.UNKNOWN
        }
        return PlanException(kind, message, status, requestId, code)
    }

    private fun extractText(response: JSONObject?): String {
        val output = response?.optJSONArray("output") ?: return ""
        val b = StringBuilder()
        for (i in 0 until output.length()) {
            val content = output.optJSONObject(i)?.optJSONArray("content") ?: continue
            for (j in 0 until content.length()) {
                val c = content.optJSONObject(j) ?: continue
                if (c.optString("type") == "output_text") b.append(c.optString("text"))
            }
        }
        return b.toString()
    }
}
