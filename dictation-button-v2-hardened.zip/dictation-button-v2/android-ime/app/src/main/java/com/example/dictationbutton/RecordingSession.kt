package com.example.dictationbutton
import java.io.File
import java.util.UUID
data class RecordingSession(val id:String=UUID.randomUUID().toString(),val editorGeneration:Long,val packageName:String?,val fieldId:Int,val file:File,val startedAtMs:Long=System.currentTimeMillis())
