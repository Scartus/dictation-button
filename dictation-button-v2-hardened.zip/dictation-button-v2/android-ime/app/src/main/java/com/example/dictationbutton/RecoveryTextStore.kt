package com.example.dictationbutton

import android.content.Context
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import android.util.Base64
import org.json.JSONObject
import java.security.KeyStore
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec

object RecoveryTextStore {
    private const val PREFS = "dictation_recovery_text"
    private const val KEY = "pending_v2"
    private const val ALIAS = "dictation_button_recovery_v2"
    private const val MAX_AGE_MS = 24 * 60 * 60 * 1000L

    fun save(context: Context, text: String) {
        val payload = JSONObject().put("saved_at", System.currentTimeMillis()).put("text", text).toString()
        val c = Cipher.getInstance("AES/GCM/NoPadding")
        c.init(Cipher.ENCRYPT_MODE, key())
        val encrypted = c.doFinal(payload.toByteArray(Charsets.UTF_8))
        val blob = Base64.encodeToString(c.iv + encrypted, Base64.NO_WRAP)
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putString(KEY, blob).commit()
    }

    fun load(context: Context): String? {
        val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val encoded = prefs.getString(KEY, null) ?: return null
        return try {
            val all = Base64.decode(encoded, Base64.NO_WRAP)
            if (all.size < 13) return null
            val c = Cipher.getInstance("AES/GCM/NoPadding")
            c.init(Cipher.DECRYPT_MODE, key(), GCMParameterSpec(128, all.copyOfRange(0, 12)))
            val j = JSONObject(String(c.doFinal(all.copyOfRange(12, all.size)), Charsets.UTF_8))
            if (System.currentTimeMillis() - j.optLong("saved_at") > MAX_AGE_MS) {
                clear(context); null
            } else j.optString("text").takeIf { it.isNotBlank() }
        } catch (_: Throwable) {
            clear(context); null
        }
    }

    fun clear(context: Context) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().remove(KEY).commit()
    }

    private fun key(): SecretKey {
        val ks = KeyStore.getInstance("AndroidKeyStore").apply { load(null) }
        (ks.getKey(ALIAS, null) as? SecretKey)?.let { return it }
        val kg = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore")
        kg.init(KeyGenParameterSpec.Builder(ALIAS, KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT)
            .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
            .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
            .build())
        return kg.generateKey()
    }
}
