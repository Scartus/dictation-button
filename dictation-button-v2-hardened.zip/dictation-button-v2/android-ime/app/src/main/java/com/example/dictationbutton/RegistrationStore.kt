package com.example.dictationbutton

import android.content.Context

object RegistrationStore {
    private const val PREFS = "chatgpt_registration_v2"
    data class Registration(val clientId: String, val subject: String?, val email: String?)

    fun load(context: Context): Registration? {
        val p = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val clientId = p.getString("client_id", null)?.takeIf { it.isNotBlank() } ?: return null
        return Registration(clientId, p.getString("subject", null), p.getString("email", null))
    }

    fun save(context: Context, clientId: String, subject: String?, email: String?) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
            .putString("client_id", clientId)
            .putString("subject", subject)
            .putString("email", email)
            .apply()
    }
}
