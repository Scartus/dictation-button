package com.example.dictationbutton

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.view.View
import android.view.inputmethod.InputMethodManager
import android.widget.Button
import android.widget.EditText
import android.widget.TextView

class SetupActivity : Activity() {
    private lateinit var status: TextView
    private lateinit var planStatus: TextView
    private lateinit var connect: Button
    private lateinit var micPermission: Button
    private lateinit var enableIme: Button
    private lateinit var chooseIme: Button
    private lateinit var disconnect: Button
    private lateinit var manageUsage: Button
    private lateinit var testField: EditText

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_setup)
        status = findViewById(R.id.setupStatus)
        planStatus = findViewById(R.id.planStatus)
        connect = findViewById(R.id.connectButton)
        micPermission = findViewById(R.id.permissionButton)
        enableIme = findViewById(R.id.enableImeButton)
        chooseIme = findViewById(R.id.selectImeButton)
        disconnect = findViewById(R.id.disconnectButton)
        manageUsage = findViewById(R.id.manageUsageButton)
        testField = findViewById(R.id.testField)

        connect.setOnClickListener {
            connect.isEnabled = false
            status.text = "Opening ChatGPT sign-in…"
            ChatGptAuthManager.signIn(this) { r ->
                connect.isEnabled = true
                r.onSuccess {
                    maybeShowPlanWelcome()
                    if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED)
                        requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 100)
                }.onFailure {
                    status.text = "Could not connect: ${it.message ?: "unknown error"}"
                }
                render()
            }
        }
        micPermission.setOnClickListener { requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 100) }
        enableIme.setOnClickListener { startActivity(Intent(Settings.ACTION_INPUT_METHOD_SETTINGS)) }
        chooseIme.setOnClickListener { (getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager).showInputMethodPicker() }
        manageUsage.setOnClickListener { openUsage() }
        disconnect.setOnClickListener { disconnectSafely() }
        render()
    }

    override fun onResume() {
        super.onResume()
        if (::status.isInitialized) render()
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        render()
    }

    private fun maybeShowPlanWelcome() {
        val prefs = getSharedPreferences("onboarding", MODE_PRIVATE)
        if (prefs.getBoolean("plan_welcome_seen", false)) return
        prefs.edit().putBoolean("plan_welcome_seen", true).apply()
        AlertDialog.Builder(this)
            .setTitle("You're using your ChatGPT plan")
            .setMessage("Eligible dictation requests in this app use your ChatGPT plan allowance. You can review or change app usage in ChatGPT Settings → Usage.")
            .setPositiveButton("Got it", null)
            .show()
    }

    private fun disconnectSafely() {
        disconnect.isEnabled = false
        status.text = "Disconnecting…"
        Thread {
            var confirmed = false
            var failed = false
            try { confirmed = ChatGptSession.revokeAndClear(this) }
            catch (_: Throwable) { failed = true; ChatGptSession.clear(this) }
            runOnUiThread {
                status.text = when {
                    confirmed -> "Disconnected from ChatGPT on this phone. The renewable session was revoked."
                    failed -> "Disconnected locally. Remote revocation could not be confirmed; you can also remove the app in ChatGPT settings."
                    else -> "Disconnected from ChatGPT on this phone."
                }
                disconnect.isEnabled = true
                render()
            }
        }.apply { name = "ChatGptRevoke"; start() }
    }

    private fun render() {
        val session = ChatGptSession.load(this)
        val connected = ChatGptSession.isConnected(this)
        val mic = checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED
        val imeEnabled = isImeEnabled()
        val imeSelected = isImeSelected()

        connect.text = if (connected) "Reconnect ChatGPT" else "Continue with ChatGPT"
        disconnect.visibility = if (connected) View.VISIBLE else View.GONE
        manageUsage.visibility = if (connected) View.VISIBLE else View.GONE
        planStatus.visibility = if (connected) View.VISIBLE else View.GONE
        testField.visibility = if (connected && mic && imeEnabled) View.VISIBLE else View.GONE

        planStatus.text = if (connected) "Using ChatGPT plan${session?.email?.let { " · $it" } ?: ""}" else ""
        micPermission.isEnabled = connected && !mic
        enableIme.isEnabled = connected && mic && !imeEnabled
        chooseIme.isEnabled = connected && mic && imeEnabled

        status.text = when {
            !connected -> "1 of 4 · Connect your ChatGPT plan. No API key or separate API billing setup is required."
            !mic -> "2 of 4 · ChatGPT connected. Allow microphone access."
            !imeEnabled -> "3 of 4 · Enable Dictation Button in Android keyboard settings."
            !imeSelected -> "4 of 4 · Choose Dictation Button as the current keyboard, then tap the test field below."
            else -> "Ready · Dictation Button is selected. Tap the test field, then Dictate."
        }
    }

    private fun isImeEnabled(): Boolean {
        val imm = getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager
        return imm.enabledInputMethodList.any { it.packageName == packageName && it.serviceName == DictationImeService::class.java.name }
    }

    private fun isImeSelected(): Boolean {
        val current = Settings.Secure.getString(contentResolver, Settings.Secure.DEFAULT_INPUT_METHOD).orEmpty()
        return current.startsWith("$packageName/") && current.contains(DictationImeService::class.java.simpleName)
    }

    private fun openUsage() {
        startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://chatgpt.com/settings/usage")))
    }
}
