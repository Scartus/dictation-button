package com.example.dictationbutton

import android.media.AudioFormat
import android.media.AudioRecord
import android.media.MediaRecorder
import java.io.File
import java.io.RandomAccessFile
import java.util.concurrent.atomic.AtomicBoolean

class WavRecorder(private val onLimitReached: (() -> Unit)? = null) {
    companion object {
        const val CHANNELS = 1
        const val BITS = 16
        const val MAX_SECONDS = 120
        private const val BYTES_PER_SAMPLE = 2
        private const val MAX_PCM_BYTES = 18_000_000L
        private val SAMPLE_RATE_CANDIDATES = intArrayOf(16_000, 24_000, 44_100, 48_000)
    }

    private val running = AtomicBoolean(false)
    private var recorder: AudioRecord? = null
    private var thread: Thread? = null
    private var output: File? = null
    private var sampleRate: Int = 16_000
    @Volatile private var failure: Throwable? = null

    fun start(file: File) {
        check(running.compareAndSet(false, true)) { "Recorder already running" }
        output = file
        failure = null
        var configured: Triple<Int, Int, AudioRecord>? = null
        for (rate in SAMPLE_RATE_CANDIDATES) {
            val min = AudioRecord.getMinBufferSize(rate, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT)
            if (min <= 0) continue
            val candidate = runCatching {
                AudioRecord(MediaRecorder.AudioSource.VOICE_RECOGNITION, rate, AudioFormat.CHANNEL_IN_MONO,
                    AudioFormat.ENCODING_PCM_16BIT, maxOf(min * 2, 8192))
            }.getOrNull() ?: continue
            if (candidate.state == AudioRecord.STATE_INITIALIZED) {
                configured = Triple(rate, min, candidate)
                break
            } else {
                candidate.release()
            }
        }
        val chosen = configured ?: run { running.set(false); error("No supported microphone sample rate found") }

        sampleRate = chosen.first
        val min = chosen.second
        val audio = chosen.third
        recorder = audio
        writeHeader(file, 0, sampleRate)
        audio.startRecording()

        thread = Thread {
            val buffer = ByteArray(maxOf(min, 4096))
            var pcmBytes = 0L
            val durationBytes = sampleRate.toLong() * CHANNELS * BYTES_PER_SAMPLE * MAX_SECONDS
            val maxBytes = minOf(durationBytes, MAX_PCM_BYTES)
            try {
                RandomAccessFile(file, "rw").use { raf ->
                    raf.seek(44)
                    while (running.get() && pcmBytes < maxBytes) {
                        val n = audio.read(buffer, 0, buffer.size)
                        when {
                            n > 0 -> { raf.write(buffer, 0, n); pcmBytes += n }
                            n < 0 && !running.get() -> break // expected wake-up after stop/cancel
                            n < 0 -> error("AudioRecord read failed: $n")
                        }
                    }
                }
                if (pcmBytes >= maxBytes && running.compareAndSet(true, false)) onLimitReached?.invoke()
            } catch (t: Throwable) {
                if (running.get()) failure = t
                running.set(false)
            } finally {
                finalizeHeader(file, pcmBytes, sampleRate)
            }
        }.apply { name = "DictationPcmRecorder"; start() }
    }

    fun stop(): Throwable? {
        running.set(false)
        try { recorder?.stop() } catch (t: Throwable) { if (failure == null) failure = t }
        joinWorker(5000)
        try { recorder?.release() } catch (_: Throwable) {}
        recorder = null; thread = null
        return failure
    }

    fun cancel() {
        running.set(false)
        try { recorder?.stop() } catch (_: Throwable) {}
        joinWorker(3000)
        try { recorder?.release() } catch (_: Throwable) {}
        recorder = null; thread = null
        output?.delete(); output = null
    }

    private fun joinWorker(timeoutMs: Long) {
        val t = thread ?: return
        try { t.join(timeoutMs) } catch (_: InterruptedException) { Thread.currentThread().interrupt() }
        if (t.isAlive) t.interrupt()
    }

    private fun writeHeader(file: File, pcmBytes: Long, rate: Int) {
        RandomAccessFile(file, "rw").use { raf -> raf.setLength(0); raf.write(ByteArray(44)); writeHeaderTo(raf, pcmBytes, rate) }
    }

    private fun finalizeHeader(file: File, pcmBytes: Long, rate: Int) {
        if (!file.exists()) return
        RandomAccessFile(file, "rw").use { writeHeaderTo(it, pcmBytes, rate) }
    }

    private fun writeHeaderTo(raf: RandomAccessFile, pcmBytes: Long, rate: Int) {
        val byteRate = rate * CHANNELS * BYTES_PER_SAMPLE
        raf.seek(0)
        raf.writeBytes("RIFF"); le32(raf, 36 + pcmBytes); raf.writeBytes("WAVEfmt "); le32(raf, 16); le16(raf, 1)
        le16(raf, CHANNELS); le32(raf, rate.toLong()); le32(raf, byteRate.toLong()); le16(raf, CHANNELS * BYTES_PER_SAMPLE); le16(raf, BITS)
        raf.writeBytes("data"); le32(raf, pcmBytes)
    }

    private fun le16(r: RandomAccessFile, v: Int) { r.write(v and 0xff); r.write((v ushr 8) and 0xff) }
    private fun le32(r: RandomAccessFile, v: Long) { repeat(4) { i -> r.write(((v ushr (8 * i)) and 0xff).toInt()) } }
}
