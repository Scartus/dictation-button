#!/usr/bin/env bash
set -euo pipefail
R="$(cd "$(dirname "$0")" && pwd)"
SRC="$R/android-ime/app/src/main/java/com/example/dictationbutton"

echo '== no API key / old proxy architecture =='
! grep -RInE 'sk-[A-Za-z0-9_-]{16,}|OPENAI_API_KEY|your-project\.vercel|gpt-transcribe' "$R/android-ime"
[ ! -d "$R/backend" ]

echo '== network allowlist in client source =='
! grep -RInE 'https?://' "$SRC" | grep -vE 'https://(auth\.openai\.com|api\.openai\.com|chatgpt\.com)|http://127\.0\.0\.1'

echo '== OAuth invariants =='
grep -q 'code_challenge_method.*S256' "$SRC/ChatGptAuthManager.kt"
grep -q 'chatgpt.tokens.use.direct' "$SRC/ChatGptAuthManager.kt"
grep -q 'ext_agent_host_id' "$SRC/ChatGptAuthManager.kt"
grep -q '127.0.0.1' "$SRC/ChatGptAuthManager.kt"
grep -Fq 'candidate["state"] == state' "$SRC/ChatGptAuthManager.kt"
grep -q 'different ChatGPT client registration' "$SRC/ChatGptAuthManager.kt"
grep -q 'Invalid ID-token signature' "$SRC/JwtVerifier.kt"
grep -q 'ID-token nonce mismatch' "$SRC/JwtVerifier.kt"
grep -q 'RegistrationStore.save' "$SRC/ChatGptSession.kt"
grep -q 'revocation_endpoint' "$SRC/ChatGptSession.kt"
grep -q 'AndroidKeyStore' "$SRC/SecureStore.kt"

echo '== Responses plan-usage invariants =='
grep -q '"store", false' "$SRC/OpenAiPlanClient.kt"
grep -q '"stream", true' "$SRC/OpenAiPlanClient.kt"
grep -q '"input_audio"' "$SRC/OpenAiPlanClient.kt"
grep -q 'response.completed' "$SRC/OpenAiPlanClient.kt"
grep -q 'subscription_sharing_usage_limit_exceeded' "$SRC/OpenAiPlanClient.kt"

echo '== dictation safety/privacy invariants =='
grep -q 'commitText' "$SRC/DictationImeService.kt"
grep -q 'session?.id != s.id' "$SRC/DictationImeService.kt"
grep -q 'isPasswordField' "$SRC/DictationImeService.kt"
grep -q 'onWindowHidden' "$SRC/DictationImeService.kt"
grep -q 'MAX_SECONDS = 120' "$SRC/WavRecorder.kt"
grep -q 'EncryptedAudioStore.save' "$SRC/DictationImeService.kt"
grep -q 'MAX_ITEMS = 1' "$SRC/EncryptedAudioStore.kt"
grep -q '24 \* 60 \* 60' "$SRC/RecoveryTextStore.kt"
! grep -q 'copyText(text)' "$SRC/DictationImeService.kt"

echo '== accessibility/usability invariants =='
grep -q 'accessibilityLiveRegion="polite"' "$R/android-ime/app/src/main/res/layout/ime_view.xml"
grep -q 'android:layout_height="72dp"' "$R/android-ime/app/src/main/res/layout/ime_view.xml"
grep -q 'Switch keyboard' "$R/android-ime/app/src/main/res/layout/ime_view.xml"
grep -q 'Test dictation here after setup' "$R/android-ime/app/src/main/res/layout/activity_setup.xml"

echo OK
