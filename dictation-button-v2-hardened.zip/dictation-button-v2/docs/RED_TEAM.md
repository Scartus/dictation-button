# Red-team record: attacks, repairs, residual risks

## Hard invariants
1. Never guess the destination editor. Auto-insert only when the recording's input-generation token and editor identity still match.
2. Never ship an OpenAI API key in the APK. Only an HTTPS proxy URL and optional user-supplied proxy token live on-device.
3. Never intentionally record password/PIN fields when Android correctly labels them.
4. Never throw away a successful transcript merely because insertion failed. Keep it in recovery and copy it.
5. Never throw away audio on network/provider failure. Move it to app-private recovery storage for Retry.
6. Ignore late results from cancelled/superseded sessions. Session ID + state must still match before insertion.
7. One recording state machine only. No parallel recorder instances.
8. Transcribe; do not silently rewrite or invent units/words.

## Repaired bottlenecks
### Wrong-app insertion race
Attack: start dictation in Notes, switch to WhatsApp while upload is in flight. Repair: input-generation token + package/field compatibility. Unsafe completion becomes recoverable text, never automatic insertion.

### Cancel/late-response race
Attack: cancel while HTTP request is already running, then start another dictation. Repair: late completion is discarded unless `session.id` is still current and state is `TRANSCRIBING`.

### Vercel body ceiling
Attack: raw 24 kHz PCM WAV grows ~48 KB/s and would exceed Vercel's 4.5 MB body ceiling quickly. Repair: mono AAC/M4A at 64 kbps, client cap ~3.8 MB, server cap 4.0 MB. Residual: prototype dictations are intentionally bounded to several minutes; long-form mode needs direct storage/upload architecture.

### Android 14+ microphone foreground-service restrictions
Attack: overlay app is backgrounded, then tries to create microphone FGS. Repair: V1 records while the IME itself is visibly active and does not need a separate microphone FGS. Bubble is deferred until the core path proves stable on the target Samsung.

### Process/network failure
Attack: provider timeout, airplane mode, proxy error, process/editor changes. Repair: failed M4A is moved from cache to app-private `files/recovery`, with up to 3 recent failed files retained and a Retry button. Retry never auto-inserts into an assumed old editor.

### Sensitive text and clipboard
Attack: password field or focus changes. Repair: password variants block start; clipboard is used only when automatic insertion is unsafe/failed. Residual: a custom app can mislabel a sensitive field; clipboard contents can be visible to the user/system and should be considered sensitive.

### API abuse
Attack: reverse-engineer APK and steal OpenAI secret. Repair: OpenAI key is server-side only. Residual: prototype `DICTATION_PROXY_TOKEN` is not strong user authentication. Production needs per-user auth, rate limits, quotas and revocation.

## Still deliberately not solved in V0.1
- Floating overlay/bubble.
- Realtime partial transcription.
- Durable transcript database.
- Per-user authentication/attestation.
- Bluetooth route recovery beyond whatever MediaRecorder/Android provides.
- Automatic handling when the 3.8 MB recorder cap is reached before the user taps Stop.
- Custom sensitive editors that lie about their input type.
- Full battery/process-death recovery while an HTTP request is actively in flight.
