# Dictation Button v0.2 — 30-cycle red-team record

Each cycle attacks a different failure surface. A cycle counts only when it has a distinct adversarial question, a repair/decision, and a regression check or explicit unresolved test.

1. **Product-goal attack — setup became a developer project.** Old design required API key + proxy + URL. **Repair:** replace proxy with Sign in with ChatGPT OSS OAuth. **Check:** source contains no backend and no API-key field.
2. **Billing attack — Plus accidentally triggers pay-as-you-go.** **Repair:** only ChatGPT-plan OAuth bearer tokens are used; no API key path. **Check:** secret scan rejects `sk-`/`OPENAI_API_KEY` patterns.
3. **OAuth-CSRF attack.** **Repair:** fresh cryptographic `state` every attempt, exact comparison on loopback callback. **Check:** audit asserts state validation.
4. **Authorization-code interception.** **Repair:** PKCE S256 with fresh verifier/challenge. **Check:** token exchange requires original verifier.
5. **Replay/ID-token substitution.** **Repair:** fresh nonce and nonce validation. **Check:** verifier rejects nonce mismatch.
6. **Forged ID token.** **Repair:** download OpenAI JWKS; verify RS256 signature, issuer, audience, expiry and nbf. **Check:** failure aborts before credential replacement.
7. **Wrong-account reauthorization.** **Repair:** persist validated `sub`; returning login must match it. **Check:** mismatched subject is rejected.
8. **Token theft at rest.** **Repair:** access/refresh/ID tokens encrypted with Android Keystore AES-GCM; app backups disabled. **Check:** audit asserts AndroidKeyStore usage.
9. **Token leakage through logs/URLs.** **Repair:** no token logging; tokens appear only in Authorization headers; ID token hint only goes to OpenAI authorization URL. **Check:** no diagnostic logger in auth path.
10. **Expired access token after one hour.** **Repair:** proactive refresh near expiry and retry after HTTP 401. **Check:** refresh path replaces rotating refresh token.
11. **Refresh race.** **Repair:** token refresh synchronized inside single app process. **Check:** concurrent callers cannot rotate the same refresh token simultaneously.
12. **Localhost callback DoS.** Another local process hits the listener first. **Repair:** listener ignores wrong path/state and continues waiting rather than consuming one connection. **Check:** only matching state completes auth.
13. **OAuth process death.** Browser may outlive app process. **Decision:** fail closed; callback listener disappears and sign-in must be retried. Do not persist PKCE verifier insecurely just to hide the failure. **Device test required.**
14. **Unsupported audio container.** Old M4A is not valid `input_audio` for Responses. **Repair:** PCM WAV recorder. **Check:** request declares `format:"wav"`.
15. **Samsung sample-rate incompatibility.** **Repair:** negotiate 16/24/44.1/48 kHz and write actual rate into WAV header. **Device test:** A55 built-in mic + Bluetooth routing.
16. **Recording continues invisibly.** **Repair:** cancel when IME window hides, input finishes or service dies. **Check:** `onWindowHidden`/`onFinishInput` enforce boundary.
17. **Password-field capture.** **Repair:** block start and insertion for password/number-password variants. **Check:** password classifier used on both paths.
18. **Wrong-app insertion after network delay.** **Repair:** bind recording to editor generation + package + field ID and refuse if changed. **Check:** guarded `commitText` only.
19. **Late response from cancelled session.** **Repair:** UUID session identity; stale responses are discarded and cannot insert. **Check:** session ID comparison before transcript handling.
20. **Double-tap recorder corruption.** **Repair:** explicit IDLE/STARTING/RECORDING/STOPPING/TRANSCRIBING state machine and atomic recorder flag. **Check:** start/stop only legal in expected states.
21. **Clipboard privacy leak.** Old fallback copied automatically. **Repair:** failed insertions remain in encrypted recovery; copying requires explicit tap. **Check:** audit rejects automatic `copyText(text)` path.
22. **IME process killed after transcription.** **Repair:** pending recovered transcript encrypted in a separate Keystore-backed store and restored with the keyboard. **Check:** pending text survives process restart without plaintext prefs.
23. **Network failure after speech.** **Repair:** failed audio moved to app-private recovery storage and exposed as Retry; only three newest retained. **Check:** successful transcript deletes temporary audio.
24. **Unlimited recording/storage exhaustion.** **Repair:** five-minute hard recording cap plus 20 MB request guard. **Check:** WAV byte bound is deterministic from sample rate.
25. **Model catalogue changes.** **Repair:** discover account-visible models, prefer current flagship slugs, test candidates and remember last successful model. **Check:** cached model invalidates on 400/404/422.
26. **Needless latency.** Old path listed models every dictation. **Repair:** successful model cached locally; ordinary dictation goes straight to Responses. **Check:** model endpoint used only on cache miss/failure.
27. **Model “helpfulness” alters medical numbers.** **Repair:** transcription instruction explicitly forbids answering, summarizing, correcting facts or adding units. **Residual risk:** model transcription is generative; benchmark against ChatGPT dictation before clinical reliance.
28. **Code-switching / accent failure.** **Decision:** do not force a language; ask for faithful transcription preserving language switching. **Device test:** English, Cantonese, mixed medical terminology.
29. **Plan-limit exhaustion/revocation.** **Repair:** API errors retain audio for retry; auth errors direct user to reconnect. **Constraint:** Plus app usage shares current ChatGPT-plan limits.
30. **False “one-click setup” claim.** Android will not silently grant mic permission or enable a third-party IME. **Repair:** three-step first-run wizard, then one-tap daily dictation. **Acceptance criterion:** no server URL, API key, model choice or recurring setup.

## Outstanding device-only gates

- Samsung A55 browser → `127.0.0.1` OAuth callback reliability.
- Android 14/One UI IME microphone behavior under one-time permission, screen lock and app switching.
- Bluetooth headset routing changes during capture.
- Responses audio transcription quality vs ChatGPT in-app dictation for the user's real accent and English/Cantonese code-switching.
- Long upload survival under Doze, weak mobile data and aggressive Samsung battery management.
- Exact model entitlement/catalogue returned by the connected Plus account at test time.
