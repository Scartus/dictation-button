# Dictation Button v2 — 50 independent red-team passes

Each pass asks a different failure question. A pass is counted only if it produced a code change, a test obligation, or an explicit residual limitation.

1. OAuth callback state replay — fresh state/nonce/PKCE per attempt; reject wrong state.
2. Returning-client substitution — reject a callback client_id that differs from the saved registration.
3. Dynamic-registration loss — retain issued registration separately from renewable tokens.
4. Wrong-account reconnect — compare verified subject with saved registration.
5. ID-token forgery — verify RS256 signature against OpenAI JWKS plus issuer/audience/nonce/exp/nbf.
6. Scope decline — do not infer plan access from identity alone; require chatgpt.tokens.use.direct.
7. Token-at-rest theft — AES-GCM under Android Keystore.
8. Token refresh race — refresh path synchronized in-process; latest replacement token persisted atomically.
9. Sign-out semantics — revoke refresh session through OIDC discovery when possible, then clear local tokens.
10. Reconnect semantics — registration mapping survives sign-out so re-registration is not needlessly repeated.
11. Stale model — cached model cleared on unsupported-model/input responses; account catalog rediscovered.
12. Model-list auth expiry — one forced refresh on 401, then fail rather than loop.
13. Stream truncation — no transcript is accepted unless response.completed is observed.
14. Mid-stream failure — response.failed/error/incomplete are terminal failures; partial text is never auto-inserted.
15. Usage limit — classify subscription_sharing_usage_limit_exceeded and expose Manage usage.
16. Temporary plan outage — 503 sharing errors preserve credentials and saved audio rather than forcing sign-out.
17. Unsupported capability — distinguish unsupported input/model from auth/network errors.
18. Request diagnostics — preserve x-request-id in user-visible failure text when present.
19. Offline before upload — detect validated network first and save encrypted audio instead of waiting for timeout.
20. Network loss during upload — fail closed; audio stays recoverable.
21. Giant WAV memory pressure — bounded recording reduced to 2 minutes and independent byte cap.
22. Sample-rate fallback inflation — byte cap is independent of sample rate.
23. Normal stop misread as recorder failure — negative AudioRecord read after running=false is expected termination.
24. Worker-thread shutdown race — bounded join before recorder release.
25. Mic start failure — no half-created session; temp file deleted.
26. Accidental tap — sub-300 ms capture is rejected without consuming plan usage.
27. Low storage — refuse to start if safe free-space margin is unavailable.
28. Process-crash temp WAV — stale cache WAV/retry files are purged.
29. Failed-audio privacy — recovery audio encrypted at rest with Android Keystore.
30. Failed-audio retention — only latest recovery recording kept; expires after 24 hours.
31. Recovery-text privacy — encrypted at rest and expires after 24 hours.
32. Recovery deletion — explicit Discard recovered text control.
33. Audio deletion — explicit Delete saved recording control.
34. Clipboard exposure — never auto-copy; clipboard use requires explicit user action.
35. Password/PIN exposure — dictation and recovery insertion blocked in password variations.
36. Editor swap while waiting — generation/package/field checks prevent late insertion into a different field.
37. Missing field IDs — if identity is ambiguous, focus change prevents auto-insert and falls back to recovery.
38. Keyboard hidden while recording — recording is cancelled rather than continuing invisibly.
39. Input field closed while recording — recording is cancelled.
40. Late response after Cancel — cleared session ID makes late results non-insertable.
41. Visual recording ambiguity — explicit Recording text, timer, Stop recording label, system mic indicator, haptic feedback.
42. TalkBack — descriptive labels; polite live status; timer excluded from continuous announcements.
43. Large text — primary actions are vertical/full-width rather than four squeezed horizontal buttons.
44. Motor accessibility — 56–72 dp targets; no gesture-only controls.
45. Voice Access/Switch Access — all essential actions are labelled buttons.
46. Cognitive load — setup screen reports four observable states: account, mic, IME enabled, IME selected.
47. Setup uncertainty — built-in test text field appears after keyboard enablement.
48. Plan transparency — persistent “Using ChatGPT plan” indication plus Manage usage in setup/error states.
49. Privacy comprehension — onboarding states audio is sent to OpenAI for transcription and chats are not exposed.
50. Architecture attack — stable IME path remains separate from future floating-overlay/accessibility experiments so launcher failures cannot corrupt the transcription/recovery core.

## Residual risks deliberately not hidden

- Physical Samsung/One UI behavior is not proven until an APK is run on the target phone.
- The voice-only IME replaces the current keyboard while selected; this is robust but adds keyboard-switch friction.
- A floating bubble that leaves Samsung Keyboard active needs a different permission/lifecycle design and must be tested separately.
- Phone calls, Bluetooth route changes, OEM battery killing, and browser loopback-OAuth behavior need device tests.
- A model can still imperfectly transcribe speech; v2 prevents partial/error responses from being treated as success but cannot guarantee semantic perfection.
- A rooted/compromised device is outside the protection offered by app-private storage and Android Keystore.
- This prototype is not a medical-record system and must not be treated as one.
