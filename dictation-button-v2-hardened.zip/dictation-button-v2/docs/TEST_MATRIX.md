# Device torture-test matrix

## Install/auth
- Fresh install; Continue with ChatGPT; approve plan use; verify callback returns to app.
- Cancel consent; wrong password; browser back; wait >3 minutes; retry.
- Reconnect same account; attempt a different account; revoke app access in ChatGPT then dictate.
- Leave app during OAuth and return; rotate screen; lock/unlock.

## Microphone
- Built-in microphone; wired headset; Bluetooth earbuds.
- Connect/disconnect Bluetooth while idle and while recording.
- Incoming call/alarm while recording.
- Hide keyboard mid-recording; switch app; lock screen; press Home.
- Very short utterance; silence; whisper; noisy room; five-minute cap.

## Text destination
- Samsung Notes, WhatsApp, Gmail, browser textarea, search field.
- Move cursor during transcription; switch fields; switch apps; close target app.
- Password/PIN fields must refuse recording.
- Selection/replacement behavior and emoji/non-Latin surrounding text.

## Network/account
- Wi-Fi off after Stop; airplane mode; weak connection; server timeout.
- Token expiry/refresh; plan limit reached; authorization revoked.
- Retry saved audio after reconnecting.

## Fidelity corpus
- Plain English prose.
- Numbers: dates, decimals, doses, phone-like digit sequences.
- Medical terminology and drug names.
- Cantonese; English→Cantonese→English code-switching.
- Punctuation commands spoken literally vs ordinary prose.
- Questions that must be transcribed, not answered.

## Recovery/privacy
- Kill IME after transcription before insertion; verify recovered text remains.
- Failed audio retention limited to three files.
- No transcript auto-copy on focus mismatch.
- Successful audio deleted; uninstall clears local credentials/data.
