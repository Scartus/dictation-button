# v2 target-device torture matrix

Run on the actual Samsung before calling the build stable.

## Setup/auth
- Fresh install; sign in once.
- Cancel sign-in.
- Wrong ChatGPT account during reconnect.
- Disconnect with network available and unavailable.
- Reconnect after disconnect.
- Expired access token / 30-day refresh expiry simulation where practical.
- Plan usage permission declined.
- Usage limit reached: Manage usage action appears.

## Recording
- 0.1 s accidental tap.
- 2 s, 30 s, 119 s, automatic 120 s stop.
- Whisper, normal speech, loud speech, background TV, wind/noise.
- English, Cantonese, and code-switching.
- Medical names, doses, decimal numbers, dates, phone numbers.
- Bluetooth connect/disconnect before and during recording.
- Incoming call/alarm during recording.
- Lock screen / hide keyboard / close field during recording.
- Low storage.

## Network
- Airplane mode before Stop.
- Disable Wi-Fi during upload.
- Captive portal / weak mobile data.
- Server 503 / rate-limit if reproducible.

## Insertion safety
- Switch WhatsApp chats during transcription.
- Switch apps during transcription.
- Switch fields in the same app.
- Password, PIN and browser password fields.
- Custom editors: Google Docs, Notion, browser contenteditable.
- Cancel while transcribing; ensure late result never inserts.

## Recovery/privacy
- Failed audio survives process restart but is encrypted.
- Retry succeeds then deletes encrypted source.
- Delete saved recording.
- Recovered text survives restart but expires after 24 h.
- Discard recovered text.
- Confirm no automatic clipboard write.
- Confirm stale cache WAV files are removed.

## Accessibility/usability
- TalkBack: all primary actions spoken correctly; status changes not spammy.
- Voice Access and Switch Access: every essential action reachable.
- Font sizes 100%, 150%, 200%.
- Display size enlarged.
- One-handed portrait use.
- Landscape orientation.
- Dark mode / high-contrast system settings.
- External hardware keyboard.

## OEM endurance
- Battery saver on/off.
- App placed in Samsung Sleeping/Deep sleeping lists.
- Screen off/on between uses.
- Reboot phone then dictate.
- Use for 30+ dictations across a day and inspect orphan files/memory.
